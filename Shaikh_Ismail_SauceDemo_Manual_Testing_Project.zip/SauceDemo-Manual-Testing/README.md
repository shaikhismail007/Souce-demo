# SauceDemo Manual Testing Project

## Project Overview
A professional, beginner-friendly manual software testing portfolio project for **SauceDemo / Swag Labs**.

- **Application:** SauceDemo / Swag Labs
- **URL:** https://www.saucedemo.com/
- **Tester:** Shaikh Ismail
- **Testing:** Manual Functional, UI, Negative and Regression Testing
- **Browser:** Google Chrome (version not verified)

## Execution Integrity
The live SauceDemo homepage was reachable through web access during preparation, but the available web interface only returned the JavaScript application's shell and could not interact with its controls. Direct network/browser automation was also unavailable. Therefore, this repository contains **no fabricated execution results, bugs or screenshots**.

All 46 test cases are currently **Not Executed**.

## Test Credentials
Public SauceDemo test accounts supplied for this project:
- `standard_user / secret_sauce`
- `locked_out_user / secret_sauce`
- `problem_user / secret_sauce`
- `error_user / secret_sauce`

Invalid combinations are also covered by the negative test cases.

## Scope
Login, logout, products, product sorting, product details, cart, checkout, order completion, negative validation, UI validation and navigation.

## Project Structure
```text
SauceDemo-Manual-Testing/
├── README.md
├── 01_Test_Plan/Test_Plan.xlsx
├── 02_Test_Scenarios/Test_Scenarios.xlsx
├── 03_Test_Cases/Test_Cases.xlsx
├── 04_Test_Execution/Test_Execution_Report.xlsx
├── 05_Bug_Reports/Bug_Report.xlsx
├── 06_Screenshots/
│   ├── Login/
│   ├── Products/
│   ├── Cart/
│   ├── Checkout/
│   └── Bugs/
└── 07_Test_Summary/Test_Summary_Report.pdf
```

## Test Scenarios
25 scenarios cover valid/invalid login, locked/problem/error users, product listing and sorting, product details, cart, checkout, order completion, logout, navigation and regression.

## Test Cases
46 manual test cases are included with:
- Preconditions
- Test data
- Numbered steps
- Expected result
- Actual result
- Status
- Priority
- Severity
- Evidence field

## Defect Reports
No defect is marked confirmed. The requested `problem_user` product-detail/Add-to-Cart investigation and `error_user` checkout/Finish investigation require actual interactive reproduction. They are **not claimed as current bugs** without evidence.

## Screenshots
Screenshot folders are present but contain only `.gitkeep`. No fake screenshots are included.

When executing manually, use names such as:
- `TC-001_Valid_Login.png`
- `TC-002_Invalid_Login.png`
- `TC-013_Product_Details.png`
- `TC-021_Checkout_Overview.png`
- `BUG-001_Product_Mismatch.png`

## Execution Summary
- Total Test Cases: 46
- Passed: 0
- Failed: 0
- Blocked: 0
- Not Executed: 46
- Not Reproducible: 0
- Pass Percentage: N/A
- Fail Percentage: N/A

Percentages use Executed Test Cases = Passed + Failed + Not Reproducible. Blocked and Not Executed are excluded.

## Known Limitations
1. No interactive Google Chrome session was available during project generation.
2. Chrome version and operating system were not verified.
3. No login, checkout or test-user behavior was claimed as executed.
4. No real payment or external transaction is involved.
5. No current defect is claimed without reproduction.
6. SauceDemo may change independently of this repository.

## How to Use
1. Open the Test Plan.
2. Execute the test cases manually in Google Chrome.
3. Enter the actual execution date only after running a test.
4. Replace `Not Executed` with the real status.
5. Record exact actual results.
6. Capture real screenshots.
7. Create a bug only after reproducing it.
8. Update the PDF summary from the real execution data.
9. Commit the repository to GitHub.

## GitHub Upload
Create a new GitHub repository, then upload this entire `SauceDemo-Manual-Testing` folder. Keep the folder structure unchanged. Do not upload private credentials or personal information.

## Instructor Submission
Tell your instructor:
> "I prepared a complete manual testing project for SauceDemo covering login, products, sorting, cart, checkout, navigation, negative testing and regression. I have kept execution evidence separate from planned documentation and have not fabricated results or defects. Interactive execution and screenshot capture are pending in the current environment."

## Tester
**Shaikh Ismail** — Manual Software Testing Portfolio Project
